/**
 * extension/popup/popup.js
 *
 * Health-check popup: pings /api/extension/health, shows per-service status
 * dots, and provides shortcuts to open the dashboard or the side panel.
 */

'use strict';

const API_BASE   = 'http://localhost:3000';
const TIMEOUT_MS = 8_000;

// ── DOM refs ──────────────────────────────────────────────────────────────

const dotBackend  = document.getElementById('dot-backend');
const dotDb       = document.getElementById('dot-db');
const dotOllama   = document.getElementById('dot-ollama');
const openPanelBtn= document.getElementById('open-panel-btn');
const versionEl   = document.getElementById('popup-version');

// ── Set dot state ─────────────────────────────────────────────────────────

function setDot(el, state, label) {
  el.className = `dot ${state}`;  // 'ok' | 'warn' | 'err' | ''
  el.title     = label || state;
}

// ── Health check ──────────────────────────────────────────────────────────

async function checkHealth() {
  // Reset to "checking" state
  setDot(dotBackend, '', 'Checking…');
  setDot(dotDb,      '', 'Checking…');
  setDot(dotOllama,  '', 'Checking…');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const res  = await fetch(`${API_BASE}/api/extension/health`, {
      signal: controller.signal,
    });
    clearTimeout(timer);

    if (!res.ok) {
      setDot(dotBackend, 'err', 'Backend error');
      setDot(dotDb,      'err', 'Unknown');
      setDot(dotOllama,  'err', 'Unknown');
      return;
    }

    const data = await res.json();

    // Backend reachable
    setDot(dotBackend, 'ok', 'Backend online');

    // Database
    setDot(dotDb,
      data.db_connected ? 'ok' : 'err',
      data.db_connected ? 'Connected' : 'DB unavailable'
    );

    // Ollama
    setDot(dotOllama,
      data.ollama_connected ? 'ok' : 'warn',
      data.ollama_connected ? 'Connected' : 'Ollama offline (templates will be used)'
    );

  } catch (err) {
    clearTimeout(timer);
    const isTimeout = err.name === 'AbortError';
    const label = isTimeout ? 'Timeout — backend not responding' : 'Backend offline';
    setDot(dotBackend, 'err', label);
    setDot(dotDb,      'err', 'Unknown (backend offline)');
    setDot(dotOllama,  'err', 'Unknown (backend offline)');
  }
}

// ── Open side panel on current tab ───────────────────────────────────────

openPanelBtn.addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tabId = tabs[0]?.id;
    if (!tabId) return;
    chrome.runtime.sendMessage({ type: 'PING' }, () => {
      // SW is alive; ask it to open the panel
      chrome.sidePanel.open({ tabId }).catch(() => {});
    });
    window.close();
  });
});

// ── Req 5.1: Token display + copy ────────────────────────────────────────

const tokenDisplay  = document.getElementById('token-display');
const copyTokenBtn  = document.getElementById('copy-token-btn');

function loadToken() {
  chrome.runtime.sendMessage({ type: 'GET_TOKEN' }, (resp) => {
    const token = resp?.token || null;
    if (tokenDisplay) {
      tokenDisplay.textContent = token ? token : '(not generated yet)';
      tokenDisplay.title = token || '';
    }
  });
}

if (copyTokenBtn && tokenDisplay) {
  copyTokenBtn.addEventListener('click', () => {
    const t = tokenDisplay.textContent.trim();
    if (!t || t.includes('not generated')) return;
    navigator.clipboard.writeText(t).then(() => {
      copyTokenBtn.textContent = '✓ Copied';
      copyTokenBtn.classList.add('copied');
      setTimeout(() => {
        copyTokenBtn.textContent = 'Copy';
        copyTokenBtn.classList.remove('copied');
      }, 2000);
    });
  });
}

// ── Show extension version from manifest ─────────────────────────────────

if (chrome.runtime?.getManifest) {
  const { version } = chrome.runtime.getManifest();
  if (versionEl) versionEl.textContent = `v${version}`;
}

// ── Init ──────────────────────────────────────────────────────────────────

checkHealth();
loadToken();
