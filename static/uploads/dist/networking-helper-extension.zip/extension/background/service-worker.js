/**
 * extension/background/service-worker.js
 *
 * MV3 Service Worker — runs as an ES module (type: "module" in manifest).
 *
 * Responsibilities:
 *   1. Listen for CONTEXT_DETECTED from the content script → open/refresh side panel.
 *   2. Listen for API_REQUEST from the side panel → proxy fetch to localhost:3000.
 *   3. Listen for GET_CONTEXT from the side panel → return last known session context.
 *   4. Handle chrome.tabs.onUpdated → close side panel when navigating away from LinkedIn.
 *   5. Handle chrome.action.onClicked → manually open panel on the active tab.
 *
 * The side panel also makes DIRECT fetch() calls to localhost:3000 for
 * long-running operations (generation, SMTP send) since the SW may be killed.
 * The API_REQUEST proxy is used only for quick, low-latency calls.
 */

const API_BASE = 'http://localhost:3000';
const LINKEDIN_ORIGIN = 'https://www.linkedin.com';
const TOKEN_KEY = 'nh_ext_token';

/** Returns the stored token, or generates+stores one if missing. */
async function getOrCreateToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get([TOKEN_KEY], (data) => {
      if (data[TOKEN_KEY]) { resolve(data[TOKEN_KEY]); return; }
      // Generate 32-char hex token
      const arr = new Uint8Array(16);
      crypto.getRandomValues(arr);
      const token = Array.from(arr).map(b => b.toString(16).padStart(2,'0')).join('');
      chrome.storage.local.set({ [TOKEN_KEY]: token }, () => resolve(token));
    });
  });
}

// ── Side panel lifecycle ──────────────────────────────────────────────────

/**
 * Open (or focus) the side panel on a given tab.
 * chrome.sidePanel.open() is only valid from a user-gesture context OR
 * from within onMessage from a content script.
 */
async function openPanel(tabId) {
  try {
    await chrome.sidePanel.open({ tabId });
  } catch (err) {
    // Ignore "user gesture" errors — panel will open on next user click
    console.warn('[NH SW] openPanel error:', err.message);
  }
}

// ── Message router ────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const { type } = msg;

  // ── CONTEXT_DETECTED (from content script) ─────────────────────────────
  if (type === 'CONTEXT_DETECTED') {
    const tabId = sender.tab?.id;
    if (tabId) {
      // Store latest context keyed by tabId for the panel to retrieve
      chrome.storage.session.set({ 
        [`nh_ctx_${tabId}`]: msg.context,
        nh_context: msg.context 
      });
      // We cannot auto-open the side panel here without a user gesture (Chrome security).
      // Instead, we ensure the panel is enabled for this tab and show a badge to prompt the user.
      chrome.sidePanel.setOptions({
        tabId,
        path: 'sidepanel/sidepanel.html',
        enabled: true,
      });
      chrome.action.setBadgeText({ text: '1', tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#0a66c2', tabId });
    }
    sendResponse({ ok: true });
    return false; // sync response
  }

  // ── GET_CONTEXT (from side panel — fetches the context for its tab) ────
  if (type === 'GET_CONTEXT') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0]?.id;
      if (!tabId) { sendResponse({ context: null }); return; }
      chrome.storage.session.get([`nh_ctx_${tabId}`, 'nh_context'], (data) => {
        const ctx = data[`nh_ctx_${tabId}`] || data['nh_context'] || null;
        sendResponse({ context: ctx });
      });
    });
    return true; // async response
  }

  // ── API_REQUEST (proxy quick fetch calls from side panel) ─────────────
  if (type === 'API_REQUEST') {
    const { method = 'GET', path, body } = msg;
    const url = `${API_BASE}${path}`;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10_000);

    getOrCreateToken().then((token) => {
      fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'x-nh-token': token,
        },
        body: body ? JSON.stringify(body) : undefined,
        signal: controller.signal,
      })
        .then(async (res) => {
          clearTimeout(timeout);
          const data = await res.json().catch(() => ({}));
          sendResponse({ ok: res.ok, status: res.status, data });
        })
        .catch((err) => {
          clearTimeout(timeout);
          sendResponse({ ok: false, status: 0, error: err.message });
        });
    });

    return true; // async response
  }

  // ── GET_TOKEN (side panel / popup retrieves the token) ───────────────
  if (type === 'GET_TOKEN') {
    getOrCreateToken().then((token) => sendResponse({ token }));
    return true; // async response
  }

  // ── PING (health check from popup or panel) ───────────────────────────
  if (type === 'PING') {
    sendResponse({ pong: true, ts: Date.now() });
    return false;
  }

  // Unknown message — ignore
  return false;
});

// ── Tab navigation tracking ───────────────────────────────────────────────

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'loading') return;
  const url = tab.url || '';

  if (!url.startsWith(LINKEDIN_ORIGIN)) {
    // Left LinkedIn — disable the side panel for this tab
    chrome.sidePanel.setOptions({ tabId, enabled: false }).catch(() => {});
    chrome.action.setBadgeText({ text: '', tabId });
  } else {
    // Re-enable when back on LinkedIn
    chrome.sidePanel.setOptions({
      tabId,
      path: 'sidepanel/sidepanel.html',
      enabled: true,
    }).catch(() => {});
  }
});

// ── Toolbar icon click → open panel manually ──────────────────────────────

chrome.action.onClicked.addListener((tab) => {
  if (tab.id) openPanel(tab.id);
});

// ── Extension install / update lifecycle ──────────────────────────────────

chrome.runtime.onInstalled.addListener(({ reason }) => {
  console.log(`[NH SW] Installed (reason: ${reason})`);

  // Generate auth token on first install (idempotent — getOrCreateToken
  // won't overwrite if the token already exists in storage.local)
  getOrCreateToken().then((token) => {
    console.log(`[NH SW] Auth token ready (first 8 chars): ${token.slice(0, 8)}…`);
  });

  // Allow the panel to open natively when the extension icon is clicked.
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});

console.log('[NH SW] Service worker started');
