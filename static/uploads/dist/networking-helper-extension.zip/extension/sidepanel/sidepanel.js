/**
 * extension/sidepanel/sidepanel.js
 *
 * Side panel controller — thin client that delegates all data operations
 * to the backend at http://localhost:3000.
 *
 * This file is the Phase 2 SKELETON. It handles:
 *   - Backend health check
 *   - Context retrieval from the service worker
 *   - UI state management (idle / active / loading)
 *   - Tab switching (Draft / History)
 *   - Stubs for enrich / generate / send / history (wired in Phase 3)
 *
 * Direct fetch() is used for all API calls (not the SW proxy) because
 * the SW may be killed during long-running operations.
 */

'use strict';

const API_BASE = 'http://localhost:3000';
const HEALTH_INTERVAL_MS = 30_000;
const API_TIMEOUT_MS     = 15_000;

// ── DOM refs ──────────────────────────────────────────────────────────────

const $ = (id) => document.getElementById(id);

const dom = {
  offlineBanner:    $('offline-banner'),
  statusDot:        $('panel-status-dot'),
  idleState:        $('idle-state'),
  activeState:      $('active-state'),
  pageTypeBadge:    $('page-type-badge'),

  // Contact card
  contactName:      $('contact-name'),
  contactTitle:     $('contact-title'),
  contactCompany:   $('contact-company'),
  contactUrl:       $('contact-url'),

  // Email
  emailInput:       $('email-input'),
  enrichBtn:        $('enrich-btn'),
  confidenceBadge:  $('confidence-badge'),

  // Company-missing notice (Req 3.1)
  companyNotice:    $('company-notice'),
  companyInput:     $('company-input'),
  companyEnrichBtn: $('company-enrich-btn'),

  // Req 4.1: Job poster-unknown notice
  posterNotice:     $('poster-notice'),
  posterInput:      $('poster-input'),
  posterEnrichBtn:  $('poster-enrich-btn'),

  // Req 4.2: Company known-contacts
  companyContactsCard:  $('company-contacts-card'),
  companyContactsCount: $('company-contacts-count'),
  companyContactsList:  $('company-contacts-list'),

  // Req 4.3: Search results
  searchResultsCard: $('search-results-card'),
  searchResultsList: $('search-results-list'),

  // Tabs
  tabDraft:         $('tab-draft'),
  tabHistory:       $('tab-history'),
  draftPane:        $('draft-pane'),
  historyPane:      $('history-pane'),

  // Draft
  subjectInput:     $('subject-input'),
  bodyTextarea:     $('body-textarea'),
  generateBtn:      $('generate-btn'),
  draftBtn:         $('draft-btn'),
  sendBtn:          $('send-btn'),
  ollamaNotice:     $('ollama-notice'),
  profileNotice:    $('profile-notice'),

  // History
  historyList:      $('history-list'),

  // Toast
  toast:            $('toast'),
};

// ── Application state ─────────────────────────────────────────────────────

const state = {
  context:    null,   // LinkedIn context from content script
  contactId:  null,   // DB contact id after enrichment
  email:      null,   // discovered or entered email
  backendOk:  false,  // backend health
  generating: false,
  sending:    false,
  nhToken:    null,   // Req 5.1: shared-secret auth token
};

// ── Req 5.1: Auth token retrieval ─────────────────────────────────────────

/**
 * Fetch the shared-secret token from the service worker (which reads
 * chrome.storage.local). Cached in state.nhToken after first call.
 */
function getToken() {
  if (state.nhToken) return Promise.resolve(state.nhToken);
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'GET_TOKEN' }, (resp) => {
      const tok = resp?.token || null;
      state.nhToken = tok;
      resolve(tok);
    });
  });
}

// ── Utilities ─────────────────────────────────────────────────────────────

/**
 * fetch() with timeout + JSON response + x-nh-token auth header.
 * Returns { ok, status, data } or throws on network error / timeout.
 */
async function apiFetch(path, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS);
  const token = await getToken();
  try {
    const res = await fetch(`${API_BASE}${path}`, {
      ...options,
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'x-nh-token': token } : {}),
        ...(options.headers || {}),
      },
    });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok, status: res.status, data };
  } finally {
    clearTimeout(timer);
  }
}

/** Show a transient toast message. */
let _toastTimer = null;
function toast(message, type = 'info', durationMs = 3000) {
  clearTimeout(_toastTimer);
  dom.toast.textContent = message;
  dom.toast.className   = `show ${type}`;
  _toastTimer = setTimeout(() => {
    dom.toast.className = '';
  }, durationMs);
}

/** Set loading state on a button. */
function setLoading(btn, loading, label) {
  btn.disabled = loading;
  if (loading) {
    btn.dataset.origLabel = btn.textContent;
    btn.textContent = label || '…';
  } else {
    btn.textContent = btn.dataset.origLabel || btn.textContent;
  }
}

// ── Health check ──────────────────────────────────────────────────────────

async function checkHealth() {
  try {
    const { ok, data } = await apiFetch('/api/extension/health');
    const healthy = ok && data.status === 'ok';
    setBackendStatus(healthy);
    return healthy;
  } catch {
    setBackendStatus(false);
    return false;
  }
}

function setBackendStatus(ok) {
  state.backendOk = ok;
  dom.statusDot.className = ok ? 'online' : 'offline';
  dom.statusDot.title     = ok ? 'Backend online' : 'Backend offline';
  dom.offlineBanner.classList.toggle('visible', !ok);
}

// ── Context retrieval ────────────────────────────────────────────────────

/** Ask the service worker for the current tab's LinkedIn context. */
function getContext() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'GET_CONTEXT' }, (resp) => {
      if (chrome.runtime.lastError) { resolve(null); return; }
      resolve(resp?.context || null);
    });
  });
}

// ── Req 5.2: Offline cache (chrome.storage.local) ────────────────────────

const CACHE_KEY = 'nh_last_ctx';

/** Save the current context to storage.local for offline fallback. */
function saveContextCache(ctx) {
  if (!ctx) return;
  try {
    chrome.storage.local.set({
      [CACHE_KEY]: { ctx, savedAt: Date.now() }
    });
  } catch {}
}

/** Load cached context from storage.local. Returns null if none. */
function loadContextCache() {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get([CACHE_KEY], (data) => {
        resolve(data[CACHE_KEY] || null);
      });
    } catch {
      resolve(null);
    }
  });
}

/** Show or hide the offline cached-data banner. */
function setCachedBanner(visible, savedAt) {
  const el = dom.offlineBanner;
  if (!visible) {
    // Restore original text if needed
    if (el.dataset.cachedMode === '1') {
      el.textContent = '⚠️ Backend offline — is networking-helper.exe running?';
      delete el.dataset.cachedMode;
    }
    return;
  }
  const age = savedAt
    ? new Date(savedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : 'unknown';
  el.textContent = `📦 Offline — showing cached data from ${age} (start networking-helper.exe to reconnect)`;
  el.dataset.cachedMode = '1';
  el.classList.add('visible');
}

// ── UI state ──────────────────────────────────────────────────────────────

function showIdle() {
  dom.idleState.hidden   = false;
  dom.activeState.hidden = true;
}

function showActive(ctx) {
  dom.idleState.hidden   = true;
  dom.activeState.hidden = false;
  renderContact(ctx);
}

/**
 * Hide all Phase 4 page-specific cards (call before showing a new page type).
 */
function hidePhase4Cards() {
  dom.posterNotice.hidden        = true;
  dom.companyContactsCard.hidden = true;
  dom.searchResultsCard.hidden   = true;
}

function renderContact(ctx) {
  if (!ctx) { showIdle(); return; }

  // Reset Phase 4 cards before each render
  hidePhase4Cards();

  // Page type badge
  const typeLabels = {
    PROFILE: 'Profile',
    JOB:     'Job Posting',
    COMPANY: 'Company',
    SEARCH:  'Search Results',
  };
  dom.pageTypeBadge.textContent = typeLabels[ctx.page_type] || ctx.page_type;
  dom.pageTypeBadge.hidden      = false;

  if (ctx.page_type === 'PROFILE') {
    dom.contactName.textContent    = ctx.full_name    || '—';
    dom.contactTitle.textContent   = ctx.title        || '';
    dom.contactCompany.textContent = ctx.company      || '';
    dom.contactUrl.textContent     = ctx.linkedin_url || ctx.url || '';
    dom.emailInput.placeholder     = 'Finding email…';

  } else if (ctx.page_type === 'JOB') {
    dom.contactName.textContent    = ctx.poster_name  || ctx.job_title || '—';
    dom.contactTitle.textContent   = ctx.job_title    || '';
    dom.contactCompany.textContent = ctx.company      || '';
    dom.contactUrl.textContent     = ctx.url          || '';
    dom.emailInput.placeholder     = 'Enter email manually';
    // Req 4.1: show poster-notice when hiring manager is unknown
    if (!ctx.poster_name) {
      dom.posterNotice.hidden = false;
    }

  } else if (ctx.page_type === 'COMPANY') {
    dom.contactName.textContent    = ctx.company      || '—';
    dom.contactTitle.textContent   = ctx.industry     || '';
    dom.contactCompany.textContent = '';
    dom.contactUrl.textContent     = ctx.url          || '';
    dom.emailInput.placeholder     = 'Not applicable';
    // Req 4.2: show company known-contacts card
    if (ctx.company) {
      dom.companyContactsCard.hidden = false;
      renderCompanyContacts(ctx.company);
    }

  } else if (ctx.page_type === 'SEARCH') {
    dom.contactName.textContent    = `${ctx.results?.length || 0} results found`;
    dom.contactTitle.textContent   = '';
    dom.contactCompany.textContent = '';
    dom.contactUrl.textContent     = '';
    dom.emailInput.placeholder     = 'Select a result below';
    // Req 4.3: show search results card
    dom.searchResultsCard.hidden = false;
    renderSearchResults(ctx.results || []);
  }
}

// ── Confidence badge ──────────────────────────────────────────────────────

function renderConfidence(confidence, source) {
  const badge = dom.confidenceBadge;
  badge.hidden = false;

  if (source === 'manual') {
    badge.className = 'medium';  // reclassified in CSS as manual-looking
    badge.textContent = '✏️ Entered manually';
    badge.className = 'confidence-badge manual';
    return;
  }

  if (confidence >= 70) {
    badge.className = 'confidence-badge high';
    badge.textContent = `✅ High confidence (${source})`;
  } else if (confidence >= 40) {
    badge.className = 'confidence-badge medium';
    badge.textContent = `⚠️ Medium confidence (pattern inferred)`;
  } else {
    badge.className = 'confidence-badge low';
    badge.textContent = `❌ Low confidence — verify email`;
  }
}

// ── Shimmer helpers ───────────────────────────────────────────────────────

function showDraftShimmer() {
  dom.subjectInput.value       = '';
  dom.bodyTextarea.value       = '';
  dom.subjectInput.placeholder = '⋯ Generating subject…';
  dom.bodyTextarea.placeholder = '⋯ Generating message…';
  dom.subjectInput.classList.add('shimmer');
  dom.bodyTextarea.classList.add('shimmer');
}

function hideDraftShimmer() {
  dom.subjectInput.classList.remove('shimmer');
  dom.bodyTextarea.classList.remove('shimmer');
}

// ── Typewriter animation (Req 3.2) ────────────────────────────────────────
/**
 * Types `text` into `field.value` character by character.
 * @param {HTMLInputElement|HTMLTextAreaElement} field
 * @param {string} text — final text
 * @param {number} msPerChar — milliseconds between characters
 * @returns {Promise<void>} resolves when animation is done
 */
function typewriter(field, text, msPerChar) {
  return new Promise((resolve) => {
    field.value = '';
    let i = 0;
    function tick() {
      if (i >= text.length) { resolve(); return; }
      field.value += text[i++];
      setTimeout(tick, msPerChar);
    }
    tick();
  });
}

// ── Tab switching ─────────────────────────────────────────────────────────

function switchTab(tabName) {
  const isDraft = tabName === 'draft';
  dom.tabDraft.classList.toggle('active', isDraft);
  dom.tabHistory.classList.toggle('active', !isDraft);
  dom.tabDraft.setAttribute('aria-selected', String(isDraft));
  dom.tabHistory.setAttribute('aria-selected', String(!isDraft));
  dom.draftPane.hidden   = !isDraft;
  dom.historyPane.hidden = isDraft;

  if (!isDraft) {
    renderHistory();
  }
}

dom.tabDraft.addEventListener('click', () => switchTab('draft'));
dom.tabHistory.addEventListener('click', () => switchTab('history'));

// ── Req 3.1: Enrich (with company-missing edge case) ─────────────────────

/**
 * Run the enrichment API call with the given company name.
 * Shared by doEnrich() and the company-notice "Find" button.
 */
async function _runEnrich(companyName) {
  const payload = {
    full_name:    state.context.full_name,
    company_name: companyName,
    linkedin_url: state.context.linkedin_url,
  };
  const { ok, data } = await apiFetch('/api/extension/enrich', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
  if (ok && data.email) {
    dom.emailInput.value = data.email;
    state.email     = data.email;
    state.contactId = data.contact_id;
    renderConfidence(data.confidence, data.source);
    dom.companyNotice.hidden = true;    // dismiss the notice on success
    toast('Email found!', 'success');
    await doGenerate();
  } else {
    dom.emailInput.placeholder = 'Not found — enter manually';
    toast('Email not found. Enter it manually.', 'info');
  }
}

async function doEnrich() {
  if (!state.context || state.context.page_type !== 'PROFILE') {
    toast('Navigate to a LinkedIn profile to find an email.', 'info');
    return;
  }

  // Req 3.1 — if no company, show the inline company-input instead of silently failing
  const company = (state.context.company || '').trim();
  if (!company) {
    dom.companyNotice.hidden = false;
    dom.companyInput.focus();
    toast('Company unknown — enter it to improve email lookup.', 'info');
    setLoading(dom.enrichBtn, false);   // not loading; waiting for user input
    return;
  }

  dom.companyNotice.hidden = true;
  setLoading(dom.enrichBtn, true, '🔍');
  try {
    await _runEnrich(company);
  } catch (err) {
    toast('Enrichment failed — is backend running?', 'error');
    console.error('[NH panel] enrich error:', err);
  } finally {
    setLoading(dom.enrichBtn, false);
  }
}

/** Triggered by the "🔍 Find" button inside the company-notice. */
async function doEnrichWithCompany() {
  const company = (dom.companyInput.value || '').trim();
  if (!company) { toast('Enter a company name first.', 'error'); return; }
  // Store it back on context so generate can use it
  if (state.context) state.context.company = company;
  setLoading(dom.companyEnrichBtn, true, '🔍');
  try {
    await _runEnrich(company);
  } catch (err) {
    toast('Enrichment failed — is backend running?', 'error');
    console.error('[NH panel] enrich (company) error:', err);
  } finally {
    setLoading(dom.companyEnrichBtn, false);
  }
}

// ── Req 3.2: Generate with typewriter reveal ──────────────────────────────

async function doGenerate() {
  if (!state.context) return;
  state.generating = true;
  setLoading(dom.generateBtn, true, '✨');
  showDraftShimmer();
  dom.ollamaNotice.hidden  = true;
  dom.profileNotice.hidden = true;

  try {
    const payload = {
      contact_context: {
        full_name:    state.context.full_name    || dom.contactName.textContent,
        title:        state.context.title        || dom.contactTitle.textContent,
        company:      state.context.company      || dom.contactCompany.textContent,
        email:        state.email                || dom.emailInput.value,
        linkedin_url: state.context.linkedin_url || null,
        job_title:    state.context.job_title    || null,
        description:  state.context.description  || null,
      },
    };
    const { ok, data } = await apiFetch('/api/extension/generate', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    if (ok) {
      hideDraftShimmer();
      dom.ollamaNotice.hidden = !data.is_fallback;
      if (!data.subject && !data.body) {
        dom.profileNotice.hidden = false;
      } else {
        // Req 3.2: typewriter reveal — subject fast (60ms/char), body slower (12ms/char)
        await typewriter(dom.subjectInput, data.subject || '', 60);
        await typewriter(dom.bodyTextarea,  data.body    || '', 12);
      }
    } else if (data?.error === 'profile_not_found') {
      hideDraftShimmer();
      dom.profileNotice.hidden = false;
    } else {
      hideDraftShimmer();
      toast('Generation failed.', 'error');
    }
  } catch (err) {
    hideDraftShimmer();
    toast('Generation failed — is backend running?', 'error');
    console.error('[NH panel] generate error:', err);
  } finally {
    state.generating = false;
    setLoading(dom.generateBtn, false);
  }
}

// ── Send stub (Phase 3 will implement) ───────────────────────────────────

async function doSend() {
  const email   = dom.emailInput.value.trim();
  const subject = dom.subjectInput.value.trim();
  const body    = dom.bodyTextarea.value.trim();

  // Client-side validation
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    toast('Enter a valid email address.', 'error'); return;
  }
  if (!subject) {
    toast('Subject cannot be empty.', 'error'); return;
  }
  if (body.length < 20) {
    toast('Message is too short (min 20 chars).', 'error'); return;
  }

  state.sending = true;
  setLoading(dom.sendBtn, true, 'Sending…');

  try {
    const payload = {
      to_email:   email,
      subject,
      body,
      contact_id: state.contactId,
      meta: {
        full_name:    state.context?.full_name    || null,
        company:      state.context?.company      || null,
        title:        state.context?.title        || null,
        linkedin_url: state.context?.linkedin_url || null,
      },
    };
    const { ok, data } = await apiFetch('/api/extension/send', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    if (ok) {
      toast('✅ Email sent!', 'success', 4000);
      switchTab('history');
    } else {
      toast(data?.error || 'Send failed.', 'error');
    }
  } catch (err) {
    toast('Send failed — is backend running?', 'error');
    console.error('[NH panel] send error:', err);
  } finally {
    state.sending = false;
    setLoading(dom.sendBtn, false);
  }
}

// ── Save draft stub (Phase 3) ─────────────────────────────────────────────

async function doDraft() {
  const subject = dom.subjectInput.value.trim();
  const body    = dom.bodyTextarea.value.trim();
  if (!subject) { toast('Subject required to save draft.', 'error'); return; }
  if (!body)    { toast('Message required to save draft.', 'error'); return; }

  setLoading(dom.draftBtn, true, '💾');
  try {
    const payload = {
      subject,
      body,
      contact_id: state.contactId,
      meta: {
        full_name:    state.context?.full_name    || null,
        company:      state.context?.company      || null,
        linkedin_url: state.context?.linkedin_url || null,
      },
    };
    const { ok } = await apiFetch('/api/extension/draft', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    toast(ok ? '💾 Draft saved!' : 'Save failed.', ok ? 'success' : 'error');
  } catch {
    toast('Save failed — is backend running?', 'error');
  } finally {
    setLoading(dom.draftBtn, false);
  }
}

// ── Req 3.4: History rendering with sentiment badges ──────────────────────

/**
 * Map a sentiment string from the DB to a badge label + CSS class.
 * Returns null for outbound messages (badges only shown on inbound).
 */
function sentimentBadge(direction, sentiment) {
  if (direction !== 'inbound' || !sentiment) return '';
  const map = {
    positive: { cls: 'positive', label: '😊 Positive' },
    neutral:  { cls: 'neutral',  label: '😐 Neutral'  },
    negative: { cls: 'negative', label: '😞 Negative' },
  };
  const entry = map[sentiment.toLowerCase()] || { cls: 'neutral', label: sentiment };
  return `<span class="sentiment-badge ${entry.cls}">${entry.label}</span>`;
}

async function renderHistory() {
  const linkedinUrl = state.context?.linkedin_url;
  if (!linkedinUrl) {
    dom.historyList.innerHTML = '<div class="empty-state"><div class="empty-state-icon">📭</div><div>No contact selected</div></div>';
    return;
  }

  dom.historyList.innerHTML = '<div class="empty-state">Loading…</div>';

  try {
    const { ok, data } = await apiFetch(
      `/api/extension/history?linkedin_url=${encodeURIComponent(linkedinUrl)}`
    );
    if (!ok || !data?.conversations?.length) {
      dom.historyList.innerHTML = '<div class="empty-state"><div class="empty-state-icon">📭</div><div>No history yet</div></div>';
      return;
    }

    dom.historyList.innerHTML = '';
    data.conversations.forEach((c) => {
      const el = document.createElement('div');
      el.className = 'convo-entry';
      const isOut  = c.direction === 'outbound';
      const date   = new Date(c.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
      const sBadge = sentimentBadge(c.direction, c.sentiment);
      el.innerHTML = `
        <div class="convo-meta">
          <span class="convo-direction ${isOut ? 'out' : 'in'}">${isOut ? '→ Sent' : '← Received'}</span>
          <span style="display:flex;gap:5px;align-items:center;">${sBadge}<span>${date}</span></span>
        </div>
        <div class="convo-subject">${escHtml(c.subject || '(no subject)')}</div>
        <div class="convo-body-preview">${escHtml(c.body || '')}</div>
      `;
      el.addEventListener('click', () => el.classList.toggle('expanded'));
      dom.historyList.appendChild(el);
    });
  } catch {
    dom.historyList.innerHTML = '<div class="empty-state">Failed to load history.</div>';
  }
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ── Req 4.1: Poster-unknown notice logic ─────────────────────────────────

/**
 * Triggered by the "🔍 Find" button in the poster-notice, or Enter key.
 * Uses the job company as domain for enrichment, name from poster-input.
 */
async function doEnrichWithPoster() {
  const posterName = (dom.posterInput.value || '').trim();
  if (!posterName) { toast('Enter the hiring manager\'s name first.', 'error'); return; }
  // Merge the entered name back into context so generate() uses it
  if (state.context) state.context.poster_name = posterName;
  const company = (state.context?.company || '').trim();
  setLoading(dom.posterEnrichBtn, true, '🔍');
  try {
    const payload = {
      full_name:    posterName,
      company_name: company,
      linkedin_url: state.context?.url || null,
    };
    const { ok, data } = await apiFetch('/api/extension/enrich', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    if (ok && data.email) {
      dom.emailInput.value = data.email;
      state.email     = data.email;
      state.contactId = data.contact_id;
      renderConfidence(data.confidence, data.source);
      dom.posterNotice.hidden = true;
      toast('Email found!', 'success');
      await doGenerate();
    } else {
      dom.emailInput.placeholder = 'Not found — enter manually';
      toast('Email not found. Enter it manually.', 'info');
    }
  } catch (err) {
    toast('Enrichment failed — is backend running?', 'error');
    console.error('[NH panel] enrich (poster) error:', err);
  } finally {
    setLoading(dom.posterEnrichBtn, false);
  }
}

// ── Req 4.2: Company known-contacts list ─────────────────────────────────

/**
 * Fetch contacts at the given company from the backend and render the list.
 */
async function renderCompanyContacts(companyName) {
  dom.companyContactsList.innerHTML = '<div class="empty-state">Loading…</div>';
  dom.companyContactsCount.textContent = '';
  try {
    const { ok, data } = await apiFetch(
      `/api/contacts?company=${encodeURIComponent(companyName)}&limit=20&sort=last_interaction&order=desc`
    );
    const contacts = ok ? (data.contacts || []) : [];
    dom.companyContactsCount.textContent =
      contacts.length === 0
        ? 'None in database yet'
        : `${contacts.length} contact${contacts.length !== 1 ? 's' : ''} found`;

    if (contacts.length === 0) {
      dom.companyContactsList.innerHTML = '<div class="empty-state">No known contacts at this company yet.</div>';
      return;
    }
    dom.companyContactsList.innerHTML = '';
    contacts.forEach((c) => {
      const row = document.createElement('div');
      row.className = 'contact-row';
      row.innerHTML = `
        <div class="contact-row-info">
          <div class="contact-row-name">${escHtml(c.full_name || '—')}</div>
          <div class="contact-row-sub">${escHtml(c.title || c.email || '')}</div>
        </div>
        <button class="btn btn-secondary btn-sm draft-email-btn" data-id="${c.id}" aria-label="Draft email to ${escHtml(c.full_name || 'contact')}">
          ✉️ Draft
        </button>
      `;
      row.querySelector('.draft-email-btn').addEventListener('click', (e) => {
        e.stopPropagation();
        loadCompanyContact(c);
      });
      dom.companyContactsList.appendChild(row);
    });
  } catch (err) {
    dom.companyContactsList.innerHTML = '<div class="empty-state">Failed to load contacts.</div>';
    console.error('[NH panel] company contacts error:', err);
  }
}

/**
 * Loads a contact from the company list into the panel as if it were a PROFILE page.
 * Switches to the Draft tab so the user can immediately draft an email.
 */
function loadCompanyContact(contact) {
  state.context = {
    page_type:    'PROFILE',
    full_name:    contact.full_name,
    title:        contact.title,
    company:      contact.company,
    linkedin_url: contact.linkedin_url,
    url:          contact.linkedin_url,
  };
  state.email     = contact.email || null;
  state.contactId = contact.id;
  // Update contact card header
  renderContact(state.context);
  // Pre-fill email if known
  if (contact.email) {
    dom.emailInput.value = contact.email;
    renderConfidence(contact.email_confidence || 0, contact.enrichment_source || 'db');
  }
  // Switch to draft tab and generate
  switchTab('draft');
  doGenerate();
  toast(`Drafting email to ${contact.full_name}…`, 'info');
}

// ── Req 4.3: Search results list ─────────────────────────────────────────

/**
 * Render search results as clickable cards.
 * Clicking a result name loads that person into profile mode.
 * "View Profile" opens their LinkedIn page in the current tab.
 */
function renderSearchResults(results) {
  if (!results.length) {
    dom.searchResultsList.innerHTML = '<div class="empty-state"><div class="empty-state-icon">🔍</div><div>No results found</div></div>';
    return;
  }
  dom.searchResultsList.innerHTML = '';
  results.forEach((r) => {
    const card = document.createElement('div');
    card.className = 'result-card';
    card.setAttribute('role', 'button');
    card.setAttribute('tabindex', '0');
    card.setAttribute('aria-label', `Select ${r.name || 'result'}`);
    card.innerHTML = `
      <div class="result-card-info">
        <div class="result-card-name">${escHtml(r.name || '—')}</div>
        <div class="result-card-title">${escHtml(r.title || '')}</div>
      </div>
      <button class="btn btn-secondary btn-sm view-profile-btn"
              data-url="${escHtml(r.linkedin_url || '')}"
              aria-label="View ${escHtml(r.name || 'profile')} on LinkedIn">
        ↗ View
      </button>
    `;
    // Clicking the card body → switch to profile mode for this person
    card.addEventListener('click', (e) => {
      if (e.target.closest('.view-profile-btn')) return; // handled by the button
      openProfileFromSearch(r);
    });
    card.addEventListener('keydown', (e) => { if (e.key === 'Enter') openProfileFromSearch(r); });
    // "View Profile" → navigate the current tab to the /in/ page
    card.querySelector('.view-profile-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      const url = r.linkedin_url;
      if (url) {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs[0]) chrome.tabs.update(tabs[0].id, { url });
        });
      } else {
        toast('No LinkedIn URL for this result.', 'info');
      }
    });
    dom.searchResultsList.appendChild(card);
  });
}

/**
 * Switches the panel to single-person (PROFILE) mode for a search result.
 * Hides the search-results-card, renders the contact card, auto-triggers enrich.
 */
function openProfileFromSearch(result) {
  if (!result.name) return;
  state.context = {
    page_type:    'PROFILE',
    full_name:    result.name,
    title:        result.title || '',
    company:      '',
    linkedin_url: result.linkedin_url || null,
    url:          result.linkedin_url || null,
  };
  state.email     = null;
  state.contactId = null;
  dom.emailInput.value = '';
  dom.confidenceBadge.hidden = true;
  renderContact(state.context);
  switchTab('draft');
  doEnrich();
  toast(`Loading ${result.name}…`, 'info');
}

// ── Event wiring ──────────────────────────────────────────────────────────

dom.enrichBtn.addEventListener('click', doEnrich);
dom.generateBtn.addEventListener('click', doGenerate);
dom.sendBtn.addEventListener('click', doSend);
dom.draftBtn.addEventListener('click', doDraft);
dom.companyEnrichBtn.addEventListener('click', doEnrichWithCompany);
dom.posterEnrichBtn.addEventListener('click', doEnrichWithPoster);
// Allow Enter key in text inputs to trigger their search
dom.companyInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') doEnrichWithCompany(); });
dom.posterInput.addEventListener('keydown',  (e) => { if (e.key === 'Enter') doEnrichWithPoster();  });

// Manual email entry clears confidence badge
dom.emailInput.addEventListener('input', () => {
  const v = dom.emailInput.value.trim();
  if (v) {
    state.email = v;
    renderConfidence(0, 'manual');
  } else {
    dom.confidenceBadge.hidden = true;
  }
});

// ── Listen for context updates from content script ────────────────────────

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'CONTEXT_DETECTED' && msg.context) {
    state.context = msg.context;
    state.email     = null;
    state.contactId = null;
    // Req 5.2: persist to offline cache on every live context update
    saveContextCache(msg.context);
    if (msg.context.page_type) {
      showActive(msg.context);         // calls renderContact which sets up Phase 4 cards
      // Auto-actions per page type
      if (msg.context.page_type === 'PROFILE') {
        doEnrich();
      }
      // JOB / COMPANY / SEARCH page-type auto-actions are handled inside renderContact
    } else {
      showIdle();
    }
  }
});

// ── Init ──────────────────────────────────────────────────────────────────

async function init() {
  // 1. Health check
  const healthy = await checkHealth();

  // 2. Fetch token (cache it in state)
  await getToken();

  // 3. Fetch current context from session storage (via SW)
  const ctx = await getContext();
  state.context = ctx;

  if (ctx && ctx.page_type) {
    // Live context — save to offline cache
    saveContextCache(ctx);
    showActive(ctx);    // calls renderContact → sets up Phase 4 cards
    if (ctx.page_type === 'PROFILE' && healthy) {
      doEnrich();
    }
    // COMPANY and SEARCH: renderContact already triggered the card renders
  } else if (!healthy) {
    // Req 5.2: Backend offline — try loading cached context
    const cached = await loadContextCache();
    if (cached && cached.ctx) {
      state.context = cached.ctx;
      showActive(cached.ctx);
      setCachedBanner(true, cached.savedAt);
    } else {
      showIdle();
    }
  } else {
    showIdle();
  }

  // 4. Periodic health check — clear cached banner when backend comes back
  setInterval(async () => {
    const wasOffline = !state.backendOk;
    await checkHealth();
    if (wasOffline && state.backendOk) {
      // Backend came back online — clear the cached banner
      setCachedBanner(false);
    }
  }, HEALTH_INTERVAL_MS);
}

init().catch(console.error);
