/**
 * extension/content/selectors.js
 *
 * Centralizes all LinkedIn CSS selectors with multi-fallback arrays per field.
 * Update this file whenever LinkedIn redesigns — nowhere else needs to change.
 *
 * Each selector array is tried left-to-right; the first match wins.
 */

// ── Page-type detectors ───────────────────────────────────────────────────

export const PAGE_TYPES = {
  /** /in/username or /in/username/ */
  PROFILE: (url) => /linkedin\.com\/in\/[^/?#]+/.test(url),
  /** /jobs/view/12345 */
  JOB:     (url) => /linkedin\.com\/jobs\/view\//.test(url),
  /** /company/acme */
  COMPANY: (url) => /linkedin\.com\/company\/[^/?#]+/.test(url),
  /** /search/results/people, /search/results/all, etc. */
  SEARCH:  (url) => /linkedin\.com\/search\/results\//.test(url),
};

/** Returns the string page-type key for a URL, or null. */
export function detectPageType(url) {
  for (const [type, test] of Object.entries(PAGE_TYPES)) {
    if (test(url)) return type;
  }
  return null;
}

// ── LinkedIn slug extraction ──────────────────────────────────────────────

/** Extract /in/<slug> from a LinkedIn profile URL. */
export function extractProfileSlug(url) {
  const m = url.match(/linkedin\.com\/in\/([^/?#]+)/);
  return m ? m[1] : null;
}

/** Extract /company/<slug> from a LinkedIn company URL. */
export function extractCompanySlug(url) {
  const m = url.match(/linkedin\.com\/company\/([^/?#]+)/);
  return m ? m[1] : null;
}

// ── CSS selector banks ────────────────────────────────────────────────────

export const SELECTORS = {

  // ── Profile page (/in/*) ─────────────────────────────────────────────
  profile: {
    /** Person's full name */
    name: [
      'h1.text-heading-xlarge',
      'h1[data-generated-suggestion-target]',
      '.pv-text-details__left-panel h1',
      '.ph5 h1',
    ],
    /** Headline / current title */
    title: [
      '.text-body-medium.break-words',
      '[data-field="headline"]',
      '.pv-text-details__left-panel .text-body-medium',
    ],
    /** Current company (from experience section top-card or right-panel) */
    company: [
      '.pv-text-details__right-panel .hoverable-link-text span[aria-hidden="true"]',
      // Older layout
      '.pv-top-card--list .pv-entity__secondary-title',
      // Inline subtitle after name (e.g. "at Acme")
      '.pv-top-card-v2-ctas .t-black--light span[aria-hidden="true"]',
    ],
    /** Location string */
    location: [
      '.pv-text-details__left-panel .text-body-small.inline.t-black--light',
      '.pv-top-card--list li:nth-child(3)',
    ],
    /** Profile image src */
    avatar: [
      '.pv-top-card-profile-picture__container img',
      '.profile-photo-edit__preview',
    ],
    /** Canonical profile URL (self-referential link) */
    canonicalUrl: [
      'link[rel="canonical"]',
    ],
  },

  // ── Job posting page (/jobs/view/*) ──────────────────────────────────
  job: {
    /** Job title */
    title: [
      '.job-details-jobs-unified-top-card__job-title h1',
      '.jobs-unified-top-card__job-title h1',
      'h1.t-24.t-bold',
    ],
    /** Hiring company name */
    company: [
      '.job-details-jobs-unified-top-card__company-name a',
      '.jobs-unified-top-card__company-name a',
      '.job-details-jobs-unified-top-card__company-name',
    ],
    /** Poster / Hiring Manager card */
    poster: [
      '.hirer-card__hirer-information .artdeco-entity-lockup__title',
      '.job-details-how-you-match__recruiter-name',
      '.hirer-card .artdeco-entity-lockup__title span[aria-hidden="true"]',
    ],
    /** Job description text container */
    description: [
      '#job-details .jobs-description__content',
      '.jobs-description-content__text',
      '.jobs-box__html-content',
    ],
    /** Job location */
    location: [
      '.job-details-jobs-unified-top-card__bullet',
      '.jobs-unified-top-card__bullet',
    ],
  },

  // ── Company page (/company/*) ─────────────────────────────────────────
  company: {
    /** Company name */
    name: [
      'h1.org-top-card-summary__title',
      '.org-top-card h1',
      'h1[data-test-id="org-top-card-summary-title"]',
    ],
    /** Industry string */
    industry: [
      '.org-top-card-summary__industry',
      '.org-top-card-summary-info-list__info-item:first-child',
    ],
    /** Tagline / description */
    tagline: [
      '.org-top-card-summary__tagline',
    ],
    /** Employee count */
    size: [
      '.org-top-card-summary-info-list__info-item span',
    ],
  },

  // ── Search results page (/search/results/*) ──────────────────────────
  search: {
    /** Container for each result card */
    resultCards: [
      '.reusable-search__result-container',
      '.entity-result__item',
      '.search-results-container li.reusable-search__result-container',
    ],
    /** Person name link inside a card */
    cardName: [
      '.entity-result__title-text a span[aria-hidden="true"]',
      '.app-aware-link span[aria-hidden="true"]',
    ],
    /** Primary subtitle (title/company) inside a card */
    cardTitle: [
      '.entity-result__primary-subtitle',
      '.entity-result__secondary-subtitle',
    ],
    /** Profile URL href on the name link */
    cardLink: [
      '.entity-result__title-text a',
      '.app-aware-link',
    ],
  },

};

// ── Utility: querySelector with fallback array ────────────────────────────

/**
 * Try each selector in `candidates` on `root` (defaults to document).
 * Returns the first matching Element, or null.
 */
export function queryFirst(candidates, root) {
  const r = root ?? (typeof document !== 'undefined' ? document : null);
  if (!r) return null;
  for (const sel of candidates) {
    try {
      const el = r.querySelector(sel);
      if (el) return el;
    } catch {
      // invalid selector — skip
    }
  }
  return null;
}

/**
 * Try each selector in `candidates` on `root`.
 * Returns NodeList/Array of all elements from the first selector that yields results.
 */
export function queryAll(candidates, root) {
  const r = root ?? (typeof document !== 'undefined' ? document : null);
  if (!r) return [];
  for (const sel of candidates) {
    try {
      const els = Array.from(r.querySelectorAll(sel));
      if (els.length > 0) return els;
    } catch {
      // invalid selector — skip
    }
  }
  return [];
}

/** Return trimmed text content of the first matching element, or empty string. */
export function getText(candidates, root) {
  const el = queryFirst(candidates, root);
  return el ? el.textContent.trim() : '';
}
