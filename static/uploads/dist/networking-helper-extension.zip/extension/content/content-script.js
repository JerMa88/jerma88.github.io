/**
 * extension/content/content-script.js
 *
 * Injected into every linkedin.com page (run_at: document_idle).
 *
 * Responsibilities:
 *   1. Detect the current LinkedIn page type on load + on SPA navigation.
 *   2. Extract structured contact context from the DOM.
 *   3. Store context in chrome.storage.session.
 *   4. Notify the service worker (CONTEXT_DETECTED) so it can open the side panel.
 *
 * SPA navigation is intercepted via history.pushState monkey-patch +
 * popstate event + MutationObserver fallback.
 *
 * NOTE: This file does NOT use import/export — MV3 content scripts are NOT
 * ES modules and cannot use top-level import statements. The selectors are
 * inlined here directly to avoid the constraint.
 */

(function () {
  'use strict';

  // ── Guard: run only once per document ────────────────────────────────────
  if (window.__nhInjected) return;
  window.__nhInjected = true;

  // ── Inline page-type detection (mirrors selectors.js, no import needed) ──

  const PAGE_TYPES = {
    PROFILE: (url) => /linkedin\.com\/in\/[^/?#]+/.test(url),
    JOB:     (url) => /linkedin\.com\/jobs\/(view|search|collections)\//.test(url),
    COMPANY: (url) => /linkedin\.com\/company\/[^/?#]+/.test(url),
    SEARCH:  (url) => /linkedin\.com\/search\/results\//.test(url),
  };

  function detectPageType(url) {
    for (const [type, test] of Object.entries(PAGE_TYPES)) {
      if (test(url)) {
        console.log('[NH] Detected page type:', type);
        return type;
      }
    }
    console.log('[NH] Unknown page type for URL:', url);
    return null;
  }

  // ── Inline selector helpers ───────────────────────────────────────────────

  function queryFirst(candidates) {
    for (const sel of candidates) {
      try {
        const el = document.querySelector(sel);
        if (el) return el;
      } catch { /* invalid selector */ }
    }
    return null;
  }

  function getText(candidates) {
    for (const sel of candidates) {
      try {
        const els = Array.from(document.querySelectorAll(sel));
        for (const el of els) {
          const text = el.textContent.trim();
          if (text) return text;
        }
      } catch { /* invalid selector */ }
    }
    return '';
  }

  function queryAll(candidates) {
    for (const sel of candidates) {
      try {
        const els = Array.from(document.querySelectorAll(sel));
        if (els.length > 0) return els;
      } catch { /* invalid selector */ }
    }
    return [];
  }

  // ── Inline selectors (must stay in sync with selectors.js) ───────────────

  const S = {
    profile: {
      name:    ['h1.text-heading-xlarge', 'h1[data-generated-suggestion-target]', '.pv-text-details__left-panel h1', '.ph5 h1', 'h1'],
      title:   ['.text-body-medium.break-words', '[data-field="headline"]', '.pv-text-details__left-panel .text-body-medium'],
      company: ['.pv-text-details__right-panel .hoverable-link-text span[aria-hidden="true"]', '.pv-top-card--list .pv-entity__secondary-title'],
      location:['.pv-text-details__left-panel .text-body-small.inline.t-black--light'],
    },
    job: {
      title:       ['.job-details-jobs-unified-top-card__job-title h1', '.jobs-unified-top-card__job-title h1', 'h1.t-24.t-bold'],
      company:     ['.job-details-jobs-unified-top-card__company-name a', '.jobs-unified-top-card__company-name a'],
      poster:      ['.hirer-card__hirer-information .artdeco-entity-lockup__title', '.hirer-card .artdeco-entity-lockup__title span[aria-hidden="true"]'],
      description: ['#job-details .jobs-description__content', '.jobs-description-content__text'],
      location:    ['.job-details-jobs-unified-top-card__bullet'],
    },
    company: {
      name:    ['h1.org-top-card-summary__title', '.org-top-card h1'],
      industry:['.org-top-card-summary__industry'],
    },
    search: {
      resultCards: ['.reusable-search__result-container', '.entity-result__item'],
      cardName:    ['.entity-result__title-text a span[aria-hidden="true"]', '.app-aware-link span[aria-hidden="true"]'],
      cardTitle:   ['.entity-result__primary-subtitle'],
      cardLink:    ['.entity-result__title-text a', '.app-aware-link'],
    },
  };

  // ── Extractors ────────────────────────────────────────────────────────────

  function extractProfileSlug(url) {
    const m = url.match(/linkedin\.com\/in\/([^/?#]+)/);
    return m ? m[1] : null;
  }

  function buildLinkedInProfileUrl(slug) {
    return slug ? `https://www.linkedin.com/in/${slug}` : null;
  }

  function extractExperienceCompanies() {
    try {
      const expDiv = document.getElementById('experience');
      if (!expDiv) return null;
      const section = expDiv.closest('section');
      if (!section) return null;
      
      const items = Array.from(section.querySelectorAll('li.artdeco-list__item'));
      let presentCompanies = [];
      
      for (const item of items) {
        const text = item.textContent;
        // Check if this experience block contains 'Present'
        if (text.includes('Present')) {
          // Find all visually hidden texts which hold the structured labels
          const spans = Array.from(item.querySelectorAll('span[aria-hidden="true"]'))
            .map(s => s.textContent.trim())
            .filter(t => t.length > 2 && !t.includes('Present') && !t.match(/mos|yrs|months|years/i));
          
          if (spans.length > 1) {
            let company = spans.length > 1 && text.includes('·') ? spans[1].split('·')[0].trim() : spans[0].split('·')[0].trim();
            presentCompanies.push(company);
          } else if (spans.length === 1) {
            presentCompanies.push(spans[0]);
          }
        }
      }
      
      if (presentCompanies.length > 0) {
        return [...new Set(presentCompanies)].join(', ');
      }
    } catch (e) {
      console.error('[NH] Experience extraction error:', e);
    }
    return null;
  }

  /**
   * Extract context from the current page based on its type.
   * Returns a context object or null if the page is unknown/not extractable.
   */
  function extractContext() {
    const url   = location.href;
    const type  = detectPageType(url);
    if (!type) return null;
    
    console.log('[NH] Extracting context for type:', type);

    let ctx = { page_type: type, url, extracted_at: Date.now() };

    if (type === 'PROFILE') {
      const slug  = extractProfileSlug(url);
      let name  = getText(S.profile.name);
      
      // Foolproof name fallback from document title (e.g. "Satya Nadella | LinkedIn")
      if (!name && document.title.includes(' | LinkedIn')) {
        name = document.title.split(' | ')[0].trim();
      }
      
      const title = getText(S.profile.title);
      let co    = extractExperienceCompanies() || getText(S.profile.company);
      
      // Foolproof company fallback: look for the first link to a company page
      if (!co) {
        const companyLinks = Array.from(document.querySelectorAll('a[href*="/company/"]'));
        for (const link of companyLinks) {
           const text = link.textContent.trim();
           // Ignore links that are empty or just say "followers"
           if (text && text.length > 2 && !text.includes('followers')) {
             co = text;
             break;
           }
        }
      }
      
      const loc   = getText(S.profile.location);
      ctx = {
        ...ctx,
        full_name:    name  || null,
        title:        title || null,
        company:      co    || null,
        location:     loc   || null,
        linkedin_url: buildLinkedInProfileUrl(slug),
        slug,
      };
    }

    else if (type === 'JOB') {
      let jobTitle  = getText(S.job.title);
      let company   = getText(S.job.company);
      
      // Foolproof fallback from document title
      if (!jobTitle || !company) {
        const docTitle = document.title;
        if (docTitle.includes(' hiring ')) {
          const match = docTitle.match(/(.+) hiring (.+?)(?: in | \| |$)/);
          if (match) {
            if (!company) company = match[1].trim();
            if (!jobTitle) jobTitle = match[2].trim();
          }
        } else if (docTitle.includes(' at ')) {
          const match = docTitle.match(/(.+) at (.+?)(?: in | \| |$)/);
          if (match) {
            if (!jobTitle) jobTitle = match[1].trim();
            if (!company) company = match[2].trim();
          }
        }
        
        // Final fallback to the primary H1 if title is completely bizarre
        if (!jobTitle) jobTitle = getText(['h1']);
      }
      
      const poster    = getText(S.job.poster);
      const descEl    = queryFirst(S.job.description);
      const descText  = descEl ? descEl.innerText.slice(0, 800) : '';
      const location  = getText(S.job.location);
      ctx = {
        ...ctx,
        job_title:    jobTitle   || null,
        company:      company    || null,
        poster_name:  poster     || null,
        description:  descText  || null,
        location:     location   || null,
        linkedin_url: null,
      };
    }

    else if (type === 'COMPANY') {
      let companyName = getText(S.company.name);
      
      // Foolproof fallback from document title
      if (!companyName && document.title.includes(' | LinkedIn')) {
        companyName = document.title.split(/[:|]/)[0].trim();
      }
      if (!companyName) {
        companyName = getText(['h1']);
      }
      
      ctx = {
        ...ctx,
        company:  companyName || null,
        industry: getText(S.company.industry) || null,
      };
    }

    else if (type === 'SEARCH') {
      const cards = queryAll(S.search.resultCards);
      ctx = {
        ...ctx,
        results: cards.slice(0, 10).map(card => ({
          name:        getText(S.search.cardName,  card),
          title:       getText(S.search.cardTitle, card),
          linkedin_url: (() => {
            const a = queryFirst ? queryFirst(S.search.cardLink) : card.querySelector(S.search.cardLink[0]);
            return a ? a.href : null;
          })(),
        })).filter(r => r.name),
      };
    }

    console.log('[NH] Extracted context:', ctx);
    return ctx;
  }

  // ── Messaging ─────────────────────────────────────────────────────────────

  let _lastContextJson = null;

  function sendContext(ctx) {
    if (!ctx) return;
    const json = JSON.stringify(ctx);
    // Skip if context hasn't changed (avoids spamming the service worker)
    if (json === _lastContextJson) return;
    _lastContextJson = json;

    try {
      chrome.runtime.sendMessage({ type: 'CONTEXT_DETECTED', context: ctx }, (resp) => {
        // Ignore "Could not establish connection" if SW was just killed
        void chrome.runtime.lastError;
      });
    } catch (err) {
      if (err.message.includes('Extension context invalidated')) {
        console.warn('[NH] Extension was updated. Please refresh the page to inject the new content script.');
        if (typeof _observer !== 'undefined' && _observer) _observer.disconnect();
      } else {
        console.error('[NH] Failed to send context:', err);
      }
    }
  }

  // ── Detection scheduler ───────────────────────────────────────────────────

  let _detectTimer = null;
  const DETECT_DELAY_MS = 800;  // after last navigation event
  const INIT_DELAY_MS   = 1500; // first page load — wait for React to render

  function scheduleDetect(delay = DETECT_DELAY_MS) {
    clearTimeout(_detectTimer);
    _detectTimer = setTimeout(() => {
      const ctx = extractContext();
      sendContext(ctx);
    }, delay);
  }

  // ── SPA navigation interception ───────────────────────────────────────────

  // 1. history.pushState monkey-patch (handles most SPA navigation)
  const origPush    = history.pushState.bind(history);
  const origReplace = history.replaceState.bind(history);

  history.pushState = (...args) => {
    origPush(...args);
    scheduleDetect();
  };
  history.replaceState = (...args) => {
    origReplace(...args);
    scheduleDetect();
  };

  // 2. popstate (browser back/forward)
  window.addEventListener('popstate', () => scheduleDetect());

  // 3. MutationObserver fallback — covers lazy-hydrated routes
  let _mutationDebounce = null;
  const _observer = new MutationObserver(() => {
    clearTimeout(_mutationDebounce);
    _mutationDebounce = setTimeout(() => {
      // Re-run regardless of URL change because DOM might have populated late
      // (e.g. LinkedIn skeleton screens).
      // sendContext automatically drops duplicate payloads.
      scheduleDetect();
    }, 1200);
  });
  _observer.observe(document.body, { childList: true, subtree: true });

  // ── Initial detection on page load ────────────────────────────────────────
  console.log('[NH] Scheduling initial detection...');
  scheduleDetect(INIT_DELAY_MS);

  console.log('[NH] Content script loaded on', location.href);

})();
